@echo off
start "" "%~dp0website\index.html"
