import { Router } from 'express';
import { z } from 'zod';
import { readCollection, writeCollection } from '../lib/store.js';
import { newRecord, asyncHandler } from '../lib/helpers.js';
import { requireAdmin } from '../lib/auth.js';

const router = Router();
const productSchema = z.object({
  name: z.string().trim().min(2).max(140),
  slug: z.string().trim().regex(/^[a-z0-9-]+$/).max(160),
  description: z.string().trim().max(4000).default(''),
  price: z.coerce.number().nonnegative(),
  salePrice: z.coerce.number().nonnegative().nullable().optional(),
  category: z.string().trim().max(100).default('general'),
  image: z.string().trim().url().optional().or(z.literal('')),
  stock: z.coerce.number().int().nonnegative().default(0),
  active: z.boolean().default(true)
});

router.get('/', asyncHandler(async (req, res) => {
  let rows = await readCollection('products');
  rows = rows.filter((row) => row.active !== false);
  if (req.query.category) rows = rows.filter((row) => row.category === req.query.category);
  if (req.query.q) {
    const q = String(req.query.q).toLowerCase();
    rows = rows.filter((row) => `${row.name} ${row.description}`.toLowerCase().includes(q));
  }
  res.json({ ok: true, count: rows.length, data: rows });
}));

router.get('/:idOrSlug', asyncHandler(async (req, res) => {
  const rows = await readCollection('products');
  const row = rows.find((item) => item.id === req.params.idOrSlug || item.slug === req.params.idOrSlug);
  if (!row || row.active === false) return res.status(404).json({ ok: false, error: 'Product not found.' });
  res.json({ ok: true, data: row });
}));

router.post('/', requireAdmin, asyncHandler(async (req, res) => {
  const parsed = productSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ ok: false, error: 'Invalid product.', details: parsed.error.flatten() });
  const rows = await readCollection('products');
  if (rows.some((row) => row.slug === parsed.data.slug)) return res.status(409).json({ ok: false, error: 'Slug already exists.' });
  const row = newRecord(parsed.data);
  rows.push(row);
  await writeCollection('products', rows);
  res.status(201).json({ ok: true, data: row });
}));

router.patch('/:id', requireAdmin, asyncHandler(async (req, res) => {
  const parsed = productSchema.partial().safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ ok: false, error: 'Invalid product update.', details: parsed.error.flatten() });
  const rows = await readCollection('products');
  const index = rows.findIndex((row) => row.id === req.params.id);
  if (index < 0) return res.status(404).json({ ok: false, error: 'Product not found.' });
  rows[index] = { ...rows[index], ...parsed.data, updatedAt: new Date().toISOString() };
  await writeCollection('products', rows);
  res.json({ ok: true, data: rows[index] });
}));

router.delete('/:id', requireAdmin, asyncHandler(async (req, res) => {
  const rows = await readCollection('products');
  const nextRows = rows.filter((row) => row.id !== req.params.id);
  if (nextRows.length === rows.length) return res.status(404).json({ ok: false, error: 'Product not found.' });
  await writeCollection('products', nextRows);
  res.json({ ok: true, message: 'Product deleted.' });
}));

export default router;
