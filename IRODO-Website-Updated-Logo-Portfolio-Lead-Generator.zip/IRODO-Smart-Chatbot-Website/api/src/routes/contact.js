import { Router } from 'express';
import { z } from 'zod';
import { appendRow, readCollection, writeCollection } from '../lib/store.js';
import { newRecord, asyncHandler } from '../lib/helpers.js';
import { requireAdmin } from '../lib/auth.js';

const router = Router();
const schema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(160).optional().or(z.literal('')),
  phone: z.string().trim().min(7).max(30).optional().or(z.literal('')),
  subject: z.string().trim().max(120).optional().or(z.literal('')),
  message: z.string().trim().min(5).max(3000),
  website: z.string().trim().max(180).optional().or(z.literal(''))
});

router.post('/', asyncHandler(async (req, res) => {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: 'Invalid form data.', details: parsed.error.flatten() });
  }

  const row = newRecord({ ...parsed.data, status: 'new' });
  await appendRow('contacts', row);
  res.status(201).json({ ok: true, message: 'Message received.', id: row.id });
}));

router.get('/', requireAdmin, asyncHandler(async (_req, res) => {
  const rows = await readCollection('contacts');
  res.json({ ok: true, count: rows.length, data: rows.slice().reverse() });
}));

router.patch('/:id/status', requireAdmin, asyncHandler(async (req, res) => {
  const statusSchema = z.object({ status: z.enum(['new', 'read', 'closed']) });
  const parsed = statusSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ ok: false, error: 'Invalid status.' });

  const rows = await readCollection('contacts');
  const index = rows.findIndex((row) => row.id === req.params.id);
  if (index < 0) return res.status(404).json({ ok: false, error: 'Message not found.' });
  rows[index] = { ...rows[index], status: parsed.data.status, updatedAt: new Date().toISOString() };
  await writeCollection('contacts', rows);
  res.json({ ok: true, data: rows[index] });
}));

export default router;
