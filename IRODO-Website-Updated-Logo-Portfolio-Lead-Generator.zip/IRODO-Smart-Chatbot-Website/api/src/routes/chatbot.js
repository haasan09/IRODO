import { Router } from 'express';
import { z } from 'zod';

const router = Router();

const schema = z.object({
  message: z.string().trim().min(1).max(700),
  history: z.array(z.object({
    role: z.enum(['user', 'bot', 'assistant']).optional(),
    content: z.string().max(1000).optional()
  })).max(12).optional().default([])
});

const packages = [
  'Starter Website: Rs. 15,000 — 1–3 pages, usually 5–7 working days.',
  'Business Website: Rs. 25,000 — up to 6 pages, usually 8–12 working days.',
  'Premium Website: Rs. 50,000 — up to 10 pages, usually 12–18 working days.',
  'Corporate Website: Rs. 75,000+ — 10–15+ pages, usually 18–25 working days.'
];

const serviceText = [
  'Business websites', 'restaurant and café websites', 'clinic and doctor websites',
  'salon websites', 'portfolio websites', 'landing pages', 'website redesign',
  'bug fixing', 'mobile responsiveness', 'basic SEO', 'speed optimisation',
  'monthly maintenance', 'e-commerce', 'digital marketing and Meta Ads'
].join(', ');

const n = (value = '') => String(value).toLowerCase().replace(/[^a-z0-9\s.+-]/g, ' ').replace(/\s+/g, ' ').trim();
const has = (t, words) => words.some((word) => t.includes(word));

function localAnswer(message) {
  const t = n(message);
  if (has(t, ['hello', 'hi', 'hey', 'salam', 'assalam', 'aoa'])) {
    return 'Assalam-o-Alaikum! I am the IRODO Smart Assistant. Ask me about services, prices, timelines, payments, SEO, Meta Ads or maintenance.';
  }
  if (has(t, ['price', 'pricing', 'package', 'cost', 'rate', 'charges', 'budget'])) {
    return `IRODO website packages:\n• ${packages.join('\n• ')}\nDomain, hosting, premium plugins, paid integrations and third-party services are charged separately when required.`;
  }
  if (has(t, ['service', 'what do you do', 'website type'])) return `IRODO offers ${serviceText}.`;
  if (has(t, ['time', 'timeline', 'delivery', 'how long', 'days'])) return 'Typical delivery is 5–7 working days for Starter, 8–12 for Business, 12–18 for Premium, and 18–25 for Corporate websites. Final timing depends on content, features and approval speed.';
  if (has(t, ['payment', 'advance', 'deposit', 'installment'])) return 'Standard payment is 50% advance, 30% after design approval, and 20% before final launch or handover. Final terms are confirmed in writing.';
  if (has(t, ['domain', 'hosting', 'plugin', 'licence', 'license'])) return 'Domain, hosting, premium plugins, licences and paid third-party integrations are quoted separately if required.';
  if (has(t, ['ecommerce', 'e commerce', 'store', 'shop website'])) return 'IRODO can build e-commerce websites with product categories, cart, checkout, payment-method setup, WhatsApp ordering and order management. The quote depends on product count and features.';
  if (has(t, ['seo', 'google ranking'])) return 'Basic on-page SEO includes titles, descriptions, heading structure, image alt text and indexing setup. Advanced monthly SEO is quoted separately.';
  if (has(t, ['meta ads', 'facebook ads', 'instagram ads', 'digital marketing'])) return 'IRODO can support digital marketing and Meta Ads. Pricing depends on campaign goals, creatives, target location, monthly management and the separate advertising budget.';
  if (has(t, ['maintenance', 'support', 'update website', 'after launch'])) return 'Monthly maintenance can include content updates, checks, backups, minor bug fixes and priority support.';
  if (has(t, ['portfolio', 'projects', 'samples', 'work'])) return 'IRODO portfolio work includes restaurant, café, clinic, doctor, dental, salon and other service-business websites.';
  return 'I can help with IRODO website services, packages, delivery time, payment terms, e-commerce, SEO, Meta Ads and maintenance. For a custom quotation, share your business type, required service, budget and WhatsApp number.';
}

router.post('/', (req, res) => {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: 'Invalid chatbot request.', details: parsed.error.flatten() });
  }
  return res.json({ ok: true, reply: localAnswer(parsed.data.message), mode: 'free-knowledge-bot' });
});

export default router;
