import { Router } from 'express';
import { z } from 'zod';
import { appendRow, readCollection } from '../lib/store.js';
import { newRecord, asyncHandler } from '../lib/helpers.js';
import { requireAdmin } from '../lib/auth.js';

const router = Router();
const schema = z.object({
  name: z.string().trim().min(2).max(80),
  phone: z.string().trim().min(7).max(30),
  email: z.string().trim().email().max(160).optional().or(z.literal('')),
  businessName: z.string().trim().max(120).optional().or(z.literal('')),
  service: z.enum(['website', 'ecommerce', 'seo', 'digital-marketing', 'meta-ads', 'branding', 'maintenance', 'other']),
  budget: z.string().trim().max(80).optional().or(z.literal('')),
  timeline: z.string().trim().max(80).optional().or(z.literal('')),
  details: z.string().trim().min(10).max(4000)
});

router.post('/', asyncHandler(async (req, res) => {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: 'Invalid quote request.', details: parsed.error.flatten() });
  }
  const row = newRecord({ ...parsed.data, status: 'new' });
  await appendRow('quotes', row);
  res.status(201).json({ ok: true, message: 'Quote request received.', id: row.id });
}));

router.get('/', requireAdmin, asyncHandler(async (_req, res) => {
  const rows = await readCollection('quotes');
  res.json({ ok: true, count: rows.length, data: rows.slice().reverse() });
}));

export default router;
