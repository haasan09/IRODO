import { Router } from 'express';
import { z } from 'zod';
import { appendRow, readCollection } from '../lib/store.js';
import { newRecord, asyncHandler } from '../lib/helpers.js';
import { requireAdmin } from '../lib/auth.js';

const router = Router();
const schema = z.object({
  event: z.string().trim().min(1).max(80),
  page: z.string().trim().max(300).optional().or(z.literal('')),
  sessionId: z.string().trim().max(120).optional().or(z.literal('')),
  meta: z.record(z.union([z.string(), z.number(), z.boolean(), z.null()])).optional()
});

router.post('/event', asyncHandler(async (req, res) => {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ ok: false, error: 'Invalid analytics event.' });
  await appendRow('analytics', newRecord({ ...parsed.data, ip: req.ip }));
  res.status(202).json({ ok: true });
}));

router.get('/summary', requireAdmin, asyncHandler(async (_req, res) => {
  const rows = await readCollection('analytics');
  const byEvent = rows.reduce((acc, row) => {
    acc[row.event] = (acc[row.event] || 0) + 1;
    return acc;
  }, {});
  const byPage = rows.reduce((acc, row) => {
    if (row.page) acc[row.page] = (acc[row.page] || 0) + 1;
    return acc;
  }, {});
  res.json({ ok: true, total: rows.length, byEvent, byPage });
}));

export default router;
