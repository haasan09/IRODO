import { Router } from 'express';
import { z } from 'zod';
import { cleanPhone } from '../lib/helpers.js';

const router = Router();
const schema = z.object({
  phone: z.string().optional(),
  customer: z.string().trim().max(100).optional().or(z.literal('')),
  address: z.string().trim().max(500).optional().or(z.literal('')),
  notes: z.string().trim().max(700).optional().or(z.literal('')),
  deliveryFee: z.coerce.number().nonnegative().default(0),
  items: z.array(z.object({
    name: z.string().trim().min(1).max(140),
    quantity: z.coerce.number().int().positive().max(99),
    price: z.coerce.number().nonnegative(),
    variant: z.string().trim().max(100).optional().or(z.literal(''))
  })).min(1).max(50)
});

router.post('/order', (req, res) => {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ ok: false, error: 'Invalid order.', details: parsed.error.flatten() });

  const phone = cleanPhone(parsed.data.phone || process.env.WHATSAPP_DEFAULT_PHONE || '');
  if (!phone) return res.status(400).json({ ok: false, error: 'WhatsApp phone number is missing.' });

  const itemLines = parsed.data.items.map((item, index) => {
    const variant = item.variant ? ` (${item.variant})` : '';
    return `${index + 1}. ${item.name}${variant} x${item.quantity} — ${item.price * item.quantity}`;
  });
  const subtotal = parsed.data.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = subtotal + parsed.data.deliveryFee;

  const lines = [
    '*New Website Order*',
    parsed.data.customer ? `Customer: ${parsed.data.customer}` : '',
    '',
    ...itemLines,
    '',
    `Subtotal: ${subtotal}`,
    `Delivery: ${parsed.data.deliveryFee}`,
    `Total: ${total}`,
    parsed.data.address ? `Address: ${parsed.data.address}` : '',
    parsed.data.notes ? `Notes: ${parsed.data.notes}` : ''
  ].filter(Boolean);

  const message = lines.join('\n');
  const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
  res.json({ ok: true, phone, subtotal, total, message, url });
});

export default router;
