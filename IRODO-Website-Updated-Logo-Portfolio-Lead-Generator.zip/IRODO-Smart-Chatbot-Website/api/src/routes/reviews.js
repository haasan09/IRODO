import { Router } from 'express';
import { z } from 'zod';
import { appendRow, readCollection, writeCollection } from '../lib/store.js';
import { newRecord, asyncHandler } from '../lib/helpers.js';
import { requireAdmin } from '../lib/auth.js';

const router = Router();
const schema = z.object({
  name: z.string().trim().min(2).max(80),
  rating: z.coerce.number().int().min(1).max(5),
  comment: z.string().trim().min(5).max(1500),
  service: z.string().trim().max(100).optional().or(z.literal(''))
});

router.post('/', asyncHandler(async (req, res) => {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ ok: false, error: 'Invalid review.', details: parsed.error.flatten() });
  const row = newRecord({ ...parsed.data, approved: false });
  await appendRow('reviews', row);
  res.status(201).json({ ok: true, message: 'Review submitted for approval.', id: row.id });
}));

router.get('/', asyncHandler(async (req, res) => {
  const rows = await readCollection('reviews');
  const admin = req.get('x-api-key') && req.get('x-api-key') === process.env.ADMIN_API_KEY;
  const data = admin ? rows : rows.filter((row) => row.approved === true);
  res.json({ ok: true, count: data.length, data: data.slice().reverse() });
}));

router.patch('/:id/approve', requireAdmin, asyncHandler(async (req, res) => {
  const parsed = z.object({ approved: z.boolean() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ ok: false, error: 'approved must be true or false.' });
  const rows = await readCollection('reviews');
  const index = rows.findIndex((row) => row.id === req.params.id);
  if (index < 0) return res.status(404).json({ ok: false, error: 'Review not found.' });
  rows[index] = { ...rows[index], approved: parsed.data.approved, updatedAt: new Date().toISOString() };
  await writeCollection('reviews', rows);
  res.json({ ok: true, data: rows[index] });
}));

export default router;
