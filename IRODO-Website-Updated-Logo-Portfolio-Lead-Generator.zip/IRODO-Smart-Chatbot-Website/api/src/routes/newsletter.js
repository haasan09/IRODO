import { Router } from 'express';
import { z } from 'zod';
import { readCollection, writeCollection } from '../lib/store.js';
import { newRecord, asyncHandler } from '../lib/helpers.js';
import { requireAdmin } from '../lib/auth.js';

const router = Router();
const schema = z.object({ email: z.string().trim().email().max(160) });

router.post('/', asyncHandler(async (req, res) => {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ ok: false, error: 'Valid email required.' });
  const rows = await readCollection('newsletter');
  if (rows.some((row) => row.email.toLowerCase() === parsed.data.email.toLowerCase())) {
    return res.json({ ok: true, message: 'Already subscribed.' });
  }
  const row = newRecord({ email: parsed.data.email, active: true });
  rows.push(row);
  await writeCollection('newsletter', rows);
  res.status(201).json({ ok: true, message: 'Subscribed successfully.' });
}));

router.get('/', requireAdmin, asyncHandler(async (_req, res) => {
  const rows = await readCollection('newsletter');
  res.json({ ok: true, count: rows.length, data: rows.slice().reverse() });
}));

export default router;
