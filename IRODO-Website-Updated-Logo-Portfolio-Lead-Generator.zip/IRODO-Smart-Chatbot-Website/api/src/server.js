import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';

import contactRoutes from './routes/contact.js';
import quoteRoutes from './routes/quotes.js';
import reviewRoutes from './routes/reviews.js';
import newsletterRoutes from './routes/newsletter.js';
import productRoutes from './routes/products.js';
import whatsappRoutes from './routes/whatsapp.js';
import analyticsRoutes from './routes/analytics.js';
import chatbotRoutes from './routes/chatbot.js';

const app = express();
const port = Number(process.env.PORT || 5000);
const origins = (process.env.CORS_ORIGINS || '*').split(',').map((value) => value.trim());

app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({
  origin(origin, callback) {
    if (!origin || origins.includes('*') || origins.includes(origin)) return callback(null, true);
    return callback(new Error('CORS origin not allowed.'));
  }
}));
app.use(express.json({ limit: '200kb' }));
app.use(morgan('tiny'));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 250, standardHeaders: true, legacyHeaders: false }));

app.get('/', (_req, res) => {
  res.json({
    name: 'IRODO Free Website API Pack',
    version: '1.0.0',
    docs: '/api',
    health: '/api/health'
  });
});

app.get('/api', (_req, res) => {
  res.json({
    public: [
      'GET /api/health',
      'POST /api/contact',
      'POST /api/quote',
      'GET /api/reviews',
      'POST /api/reviews',
      'POST /api/newsletter',
      'GET /api/products',
      'GET /api/products/:idOrSlug',
      'POST /api/whatsapp/order',
      'POST /api/analytics/event',
      'POST /api/chatbot'
    ],
    adminHeader: 'x-api-key: YOUR_ADMIN_API_KEY',
    admin: [
      'GET /api/contact',
      'PATCH /api/contact/:id/status',
      'GET /api/quote',
      'GET /api/newsletter',
      'POST /api/products',
      'PATCH /api/products/:id',
      'DELETE /api/products/:id',
      'PATCH /api/reviews/:id/approve',
      'GET /api/analytics/summary'
    ]
  });
});

app.get('/api/health', (_req, res) => res.json({ ok: true, status: 'online', time: new Date().toISOString() }));
app.use('/api/contact', contactRoutes);
app.use('/api/quote', quoteRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/newsletter', newsletterRoutes);
app.use('/api/products', productRoutes);
app.use('/api/whatsapp', whatsappRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/chatbot', chatbotRoutes);

app.use((_req, res) => res.status(404).json({ ok: false, error: 'Route not found.' }));
app.use((error, _req, res, _next) => {
  console.error(error);
  if (error.message === 'CORS origin not allowed.') return res.status(403).json({ ok: false, error: error.message });
  res.status(500).json({ ok: false, error: 'Internal server error.' });
});

app.listen(port, () => {
  console.log(`IRODO API running on http://localhost:${port}`);
});
