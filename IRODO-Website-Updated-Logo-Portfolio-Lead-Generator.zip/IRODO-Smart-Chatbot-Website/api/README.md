# IRODO Free Website API Pack

A reusable Node.js API starter for client websites. It uses local JSON files, so it does not require a paid database or paid API key.

## Included APIs

- Contact form submissions
- Website/service quote requests
- Customer reviews with admin approval
- Newsletter subscriptions
- Product listing and admin CRUD
- WhatsApp order-link generator
- Lightweight website event analytics
- Admin-key protection, validation, CORS, security headers and rate limiting

## Quick start

1. Install Node.js 18 or newer.
2. Open this folder in Terminal.
3. Run:

```bash
npm install
cp .env.example .env
npm run dev
```

On Windows, copy `.env.example` and rename the copy to `.env`.

Open:

- API status: `http://localhost:5000/api/health`
- Endpoint list: `http://localhost:5000/api`
- Demo form: open `demo/index.html`

## Important configuration

Edit `.env`:

```env
PORT=5000
ADMIN_API_KEY=use-a-long-random-secret-here
CORS_ORIGINS=https://clientsite.com,https://www.clientsite.com
WHATSAPP_DEFAULT_PHONE=923001234567
```

Never expose `ADMIN_API_KEY` inside frontend JavaScript. Use it only from a private admin panel or server-side code.

## Frontend contact-form example

```js
const response = await fetch('https://your-api-domain.com/api/contact', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'Ali Khan',
    email: 'ali@example.com',
    phone: '03001234567',
    subject: 'Website project',
    message: 'I need an ecommerce website.'
  })
});

const data = await response.json();
console.log(data);
```

## Admin example

```js
const response = await fetch('https://your-api-domain.com/api/contact', {
  headers: { 'x-api-key': 'YOUR_PRIVATE_ADMIN_KEY' }
});
```

## WhatsApp order generator example

```js
const response = await fetch('https://your-api-domain.com/api/whatsapp/order', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    phone: '923001234567',
    customer: 'Sara',
    address: 'Faisal Hills, Taxila',
    deliveryFee: 150,
    items: [
      { name: 'Zinger Burger', quantity: 2, price: 650, variant: 'Spicy' },
      { name: 'Drink', quantity: 1, price: 180 }
    ]
  })
});

const data = await response.json();
window.open(data.url, '_blank');
```

## Data storage

Records are saved in the `data/` folder as JSON files. This is suitable for demos, prototypes and low-traffic websites. For large or business-critical websites, replace the storage module with PostgreSQL, MySQL, Supabase, Firebase or another managed database.

## Reusing it for clients

For every client:

1. Make a separate deployment.
2. Change `ADMIN_API_KEY`.
3. Restrict `CORS_ORIGINS` to that client's website.
4. Change the WhatsApp number.
5. Keep regular backups of the `data/` folder.

## API routes

### Public

- `GET /api/health`
- `POST /api/contact`
- `POST /api/quote`
- `GET /api/reviews`
- `POST /api/reviews`
- `POST /api/newsletter`
- `GET /api/products`
- `GET /api/products/:idOrSlug`
- `POST /api/whatsapp/order`
- `POST /api/analytics/event`

### Admin (`x-api-key` required)

- `GET /api/contact`
- `PATCH /api/contact/:id/status`
- `GET /api/quote`
- `GET /api/newsletter`
- `POST /api/products`
- `PATCH /api/products/:id`
- `DELETE /api/products/:id`
- `PATCH /api/reviews/:id/approve`
- `GET /api/analytics/summary`

## Limitations

This package does not send email or SMS by itself because those services normally require external credentials and may have paid usage. It safely stores requests and creates WhatsApp links without paid third-party APIs.
