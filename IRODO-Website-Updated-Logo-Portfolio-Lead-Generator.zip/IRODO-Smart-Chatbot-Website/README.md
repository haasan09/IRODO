# IRODO Smart Chatbot Website

This package contains:

- `website/index.html` — IRODO website with the chatbot already installed.
- `website/chatbot-widget.js` — reusable smart chatbot widget.
- `website/chatbot-widget.css` — responsive chatbot styling.
- `website/assets/irodo-logo.png` — IRODO chatbot logo.
- `api/` — the earlier IRODO free API pack, now with `POST /api/chatbot`.

## Quickest method — no server required

1. Open the `website` folder.
2. Double-click `index.html`.
3. The chatbot works immediately using its built-in IRODO knowledge base.

The free offline mode answers common questions about:

- Services
- Website packages and prices
- Delivery times
- Payment terms
- Domain and hosting
- E-commerce websites
- SEO
- Digital marketing and Meta Ads
- Maintenance and support
- Portfolio
- WhatsApp contact
- Step-by-step quotation collection

## Connect the API

Open `website/index.html` and find:

```js
apiBaseUrl: ""
```

Change it to your API address, for example:

```js
apiBaseUrl: "http://localhost:5000"
```

Then run the API:

```bash
cd api
npm install
npm run dev
```

API endpoint:

```text
POST /api/chatbot
```

Example request:

```json
{
  "message": "What are your website prices?",
  "history": []
}
```

## Important security note

The included bot is free and does not expose any paid AI key in the browser. It is a focused business assistant, not a general-purpose ChatGPT replacement. For a cloud generative-AI model, connect it through the server API only; never place a secret AI key directly inside website JavaScript.

## Edit WhatsApp number

In `website/index.html`, change:

```js
whatsapp: "923215602867"
```

Use country code format without `+`, spaces or dashes.


## Latest IRODO branding update

- Original IRODO logo added to the navigation, footer and chatbot.
- Theme updated with dark navy, electric blue and cyan brand colours.
- Live portfolio links added for Safa Cafe, Care 32, Noor Beauty Salon, Dr. Tania Habib and Cafe District 17.
- Delizo portfolio card replaced with Cafe District 17.
- Free Website Audit lead generator added with WhatsApp handoff.
- New services added: AI chatbot integration, lead-generation systems, e-commerce, admin dashboards, Meta Ads landing pages, booking systems and local SEO.
